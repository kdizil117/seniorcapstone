# US States GeoJSON

This repository contains a file of GEOJSON for every US state. The data is sourced from:

* http://eric.clst.org/Stuff/USGeoJSON
* Wikipedia

Have fun!
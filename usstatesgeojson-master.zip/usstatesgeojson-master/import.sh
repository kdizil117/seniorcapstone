#!/bin/bash
ccurl -X POST -d @alabama.geojson /usstates
ccurl -X POST -d @alaska.geojson /usstates
ccurl -X POST -d @arizona.geojson /usstates
ccurl -X POST -d @arkansas.geojson /usstates
ccurl -X POST -d @california.geojson /usstates
ccurl -X POST -d @colorado.geojson /usstates
ccurl -X POST -d @connecticut.geojson /usstates
ccurl -X POST -d @delaware.geojson /usstates
ccurl -X POST -d @florida.geojson /usstates
ccurl -X POST -d @georgia.geojson /usstates
ccurl -X POST -d @hawaii.geojson /usstates
ccurl -X POST -d @idaho.geojson /usstates
ccurl -X POST -d @illinois.geojson /usstates
ccurl -X POST -d @indiana.geojson /usstates
ccurl -X POST -d @iowa.geojson /usstates
ccurl -X POST -d @kansas.geojson /usstates
ccurl -X POST -d @kentucky.geojson /usstates
ccurl -X POST -d @louisiana.geojson /usstates
ccurl -X POST -d @maine.geojson /usstates
ccurl -X POST -d @maryland.geojson /usstates
ccurl -X POST -d @massachusetts.geojson /usstates
ccurl -X POST -d @michigan.geojson /usstates
ccurl -X POST -d @minnesota.geojson /usstates
ccurl -X POST -d @mississippi.geojson /usstates
ccurl -X POST -d @missouri.geojson /usstates
ccurl -X POST -d @montana.geojson /usstates
ccurl -X POST -d @nebraska.geojson /usstates
ccurl -X POST -d @nevada.geojson /usstates
ccurl -X POST -d @new\ hampshire.geojson /usstates
ccurl -X POST -d @new\ jersey.geojson /usstates
ccurl -X POST -d @new\ mexico.geojson /usstates
ccurl -X POST -d @new\ york.geojson /usstates
ccurl -X POST -d @north\ carolina.geojson /usstates
ccurl -X POST -d @north\ dakota.geojson /usstates
ccurl -X POST -d @ohio.geojson /usstates
ccurl -X POST -d @oklahoma.geojson /usstates
ccurl -X POST -d @oregon.geojson /usstates
ccurl -X POST -d @pennsylvania.geojson /usstates
ccurl -X POST -d @rhode\ island.geojson /usstates
ccurl -X POST -d @south\ carolina.geojson /usstates
ccurl -X POST -d @south\ dakota.geojson /usstates
ccurl -X POST -d @tennessee.geojson /usstates
ccurl -X POST -d @texas.geojson /usstates
ccurl -X POST -d @utah.geojson /usstates
ccurl -X POST -d @vermont.geojson /usstates
ccurl -X POST -d @virginia.geojson /usstates
ccurl -X POST -d @washington.geojson /usstates
ccurl -X POST -d @west\ virginia.geojson /usstates
ccurl -X POST -d @wisconsin.geojson /usstates
ccurl -X POST -d @wyoming.geojson /usstates
ccurl -X POST -d @design-fetch.json /usstates

